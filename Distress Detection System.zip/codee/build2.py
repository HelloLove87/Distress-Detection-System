import assemblyai as aai
from fuzzywuzzy import fuzz, process

# Replace with your API key
aai.settings.api_key = "d0b5313d634545f3a8dc81e9fdf9e3f6"

# List of distress keywords
distress_keywords = [
    "Urgent help needed!", "Emergency situation!", "Immediate assistance required!",
    "Life-threatening crisis!", "Critical danger, respond ASAP!", "Please dispatch help now!",
    "Serious threat, intervene!", "Dangerous situation unfolding!", "Immediate intervention necessary!",
    "Report urgent incident!", "Please assist immediately!", "Respond to critical emergency!",
    "Life in imminent danger!", "Situation is dire!", "Need authorities on-site now!",
    "Call for emergency response!", "Respond urgently!", "Help required urgently!",
    "Immediate action required!", "Respond ASAP, urgent crisis!", "Critical incident, respond now!",
    "Dispatch help immediately!", "Dangerous circumstances, act fast!", "Request immediate assistance!",
    "Urgent situation, deploy responders!", "Emergency, need help now!", "Serious trouble, call authorities!",
    "Dangerous situation, please help!", "Immediate support necessary!", "Report critical incident!",
    "Life at risk, respond urgently!", "Seeking help for dire situation!", "Respond quickly, urgent situation!",
    "Immediate intervention needed!", "Crisis unfolding, respond now!", "Urgent call for assistance!",
    "Notify authorities, immediate!", "Threat escalating, act now!", "Emergency alert, respond urgently!",
    "Urgent distress, send help!", "Dangerous conditions, please respond!", "Critical help required!",
    "Emergency assistance needed!", "Time-sensitive crisis, act now!", "Report life-threatening situation!",
    "Urgent distress signal, respond!", "Situation is critical, respond fast!", "Requesting immediate intervention!",
    "Crisis situation, respond urgently!", "Life in peril, respond immediately!", "Notify authorities, urgent!",
    "Emergency response needed!", "Critical incident, act now!", "Immediate attention required!",
    "Urgent call for intervention!", "Emergency situation, respond fast!", "Need help urgently, critical!",
    "Request urgent support!", "Life-threatening issue, respond now!", "Act fast, dangerous situation!",
    "Critical distress, immediate response!", "Emergency alert, respond promptly!", "Urgent assistance required!",
    "Notify authorities, critical!", "Crisis unfolding, respond ASAP!", "I need help immediately!",
    "I think I am going to die!", "pain", "injury", "bleeding", "difficulty breathing",
    "chest pain", "choking", "unconscious", "seizure", "heart attack", "stroke", "burn",
    "allergic reaction", "fracture", "drowning", "poisoning", "head injury", "shock",
    "asthma attack", "diabetic emergency", "dehydration", "heatstroke", "hypothermia",
    "anaphylaxis", "panic attack", "self-harm", "overdose", "loss of consciousness", "vomiting",
    "swelling", "nausea", "disorientation", "confusion", "agitation", "numbness", "tingling",
    "suicidal thoughts", "hallucination", "shortness of breath", "fainting", "paralysis",
    "vision loss", "speech difficulty", "coughing blood", "rapid heartbeat", "dislocated joint",
    "severe headache", "severe abdominal pain", "pale skin", "pupils unequal", "severe cramps",
    "difficulty swallowing", "burning sensation", "loss of balance", "sudden weakness",
    "difficulty speaking", "severe back pain", "bloody stool", "severe fatigue", "sudden weight loss",
    "excessive thirst", "dark urine", "severe itching", "bruising easily", "bleeding gums",
    "severe sweating", "high fever", "seizure warning signs", "uncontrolled shaking",
    "discoloration of skin", "swollen lymph nodes", "rapid breathing", "high blood pressure",
    "low blood pressure", "blurred vision", "difficulty seeing", "blackout", "hot flashes",
    "cold sweats", "severe vomiting", "severe diarrhea", "trouble hearing", "ringing in ears",
    "extreme thirst", "extreme hunger", "extreme fatigue", "muscle weakness", "loss of motor control",
    "loss of sensation", "severe chest tightness", "rash", "hives", "swollen face", "swollen tongue",
    "rapid weight gain", "joint pain", "muscle cramps", "itchy skin", "lightheadedness", "palpitations",
    "gasping for breath", "difficulty urinating", "severe abdominal bloating", "sudden disorientation",
    "severe mood swings", "extreme sadness", "extreme anxiety", "extreme anger", "extreme irritability",
    "extreme restlessness", "sudden change in behavior", "threatening self-harm", "suicidal behavior",
    "extreme fatigue", "loss of appetite", "severe insomnia", "severe nightmares", "obsessive thoughts",
    "hallucinations", "delusions", "paranoia", "rapid weight loss", "complete withdrawal",
    "catatonia", "unresponsiveness", "loss of contact with reality", "extreme aggression",
    "severe agitation", "extreme social withdrawal", "self-isolation", "neglect of personal hygiene",
    "severe neglect of responsibilities", "incoherent speech", "disorganized thoughts",
    "extreme confusion", "extreme disorientation", "severe disassociation", "extreme paranoia",
    "severe panic", "extreme fear", "intense guilt", "extreme shame",
]

# Initialize AssemblyAI Transcriber
transcriber = aai.Transcriber()

def detect_distress(text):
    # Match the distress keywords with some tolerance for partial matches
    for keyword in distress_keywords:
        if fuzz.partial_ratio(keyword.lower(), text.lower()) > 80:  # Adjust threshold as needed
            return True
    return False

# Transcribe the audio file
def transcribe_audio(file_url):
    transcript = transcriber.transcribe(file_url)
    if transcript.status == aai.TranscriptStatus.error:
        print(f"Error: {transcript.error}")
    else:
        return transcript.text

# Example usage
file_url = 'trail2.mp3'  # Update with your file path or URL
transcript_text = transcribe_audio(file_url)

if transcript_text:
    print("Transcript:")
    print(transcript_text)
    
    if detect_distress(transcript_text):
        print("Distress detected! Triggering alert...")
        # Implement your alert system here
    else:
        print("No distress detected.")
